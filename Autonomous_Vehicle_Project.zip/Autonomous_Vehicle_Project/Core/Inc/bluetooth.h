/*
 * bluetooth.h
 *
 *  Created on: Oct 11, 2024
 *      Author: jsmok
 */

#ifndef INC_BLUETOOTH_H_
#define INC_BLUETOOTH_H_

#include "top.h"

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart );
//void UART6INIT(void);

#endif /* INC_BLUETOOTH_H_ */
